
Logged in as `james` user:

![[Pasted image 20220410103216.png]]

Checked for `sudo` version:

```bash
james@hackernote:~$ apt show sudo                                               
Package: sudo                                                                   
Version: 1.8.21p2-3ubuntu1.2                                                    
Priority: important                                                             
Section: admin                                                                  
Origin: Ubuntu                                                                  
Maintainer: Ubuntu Developers <ubuntu-devel-discuss@lists.ubuntu.com>            
Original-Maintainer: Bdale Garbee <bdale@gag.com>                               
Bugs: https://bugs.launchpad.net/ubuntu/+filebug                                
Installed-Size: 1,765 kB                                                        
Depends: libaudit1 (>= 1:2.2.1), libc6 (>= 2.27), libpam0g (>= 0.99.7.1), libselinux1 (>= 1.32), libpam-modules, lsb-base
Conflicts: sudo-ldap                                                            
Replaces: sudo-ldap                                                             
Homepage: http://www.sudo.ws/                                                   
Task: minimal                                                                   
Supported: 5y                                                                   
Download-Size: 427 kB                                                           
APT-Sources: http://archive.ubuntu.com/ubuntu bionic-updates/main amd64 Packages 
Description: Provide limited super user privileges to specific users             
 Sudo is a program designed to allow a sysadmin to give limited root             
 privileges to users and log root activity.  The basic philosophy is to give     
 as few privileges as possible but still allow people to get their work done.    
 .                                                                                                                     
 This version is built with minimal shared library dependencies, use the
 sudo-ldap package instead if you need LDAP support for sudoers.        
                                                                                                                       
N: There is 1 additional record. Please use the '-a' switch to see it
```

Its version is under ***1.8.30***, which means it's vulnerable to [CVE-2019-18634](https://github.com/saleemrashid/sudo-cve-2019-18634).

The exploit ran perfectly:

![[Pasted image 20220410104356.png]]

